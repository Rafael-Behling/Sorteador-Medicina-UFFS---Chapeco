# CampeANATO - Sorteador e Painel

Sistema HTA (HTML Application) para sorteios e controle de ranking no CampeANATO.

## Estrutura
- Sorteador.hta - Tela do projetor (sorteio de temas/n�meros)
- Painel.hta - Painel de controle (grupos, pontos, cron�metro)
- SONS/ - Arquivos de �udio
  - som da roleta girando.wav
  - pergunta_trunc.wav / sino.wav (sino nos �ltimos 2 segundos)
- playsound.exe - Helper para reprodu��o de �udio
- TOPICOS/, NUMEROS/, FUNDO/ - Imagens
